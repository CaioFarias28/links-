function geraarrayaeUrl(arrayLinks){
    return arraylinks.map(objetoLink => Object.values(objetoLink).join())
}
function validaURLArray(arraylinks){
    return geraarrayaeUrl(arraylinks)
}
export default validaURLArray;
